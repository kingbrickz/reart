<?php
  include '../settings/connection.php';
  session_start();
  $user_id = $_SESSION['ID'];

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>User Profile</title>
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <!-- Font Awesome CSS -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <!-- Custom CSS -->
  <link rel="stylesheet" href="./css/profile.css"> <!-- Added profile.css -->
</head>
<body>

<div class="row py-5 px-4">
  <div class="col-md-5 mx-auto">
    <!-- Profile widget -->
    <div class="bg-white shadow rounded overflow-hidden">
      <div class="px-4 pt-0 pb-4 cover">
        <div class="media align-items-end profile-head">
          <div class="profile mr-3">
            <img src="https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=80" alt="..." width="130" class="rounded mb-2 img-thumbnail">
            <button class="btn btn-outline-dark btn-sm btn-block" onclick="openProfilePictureModal()">Edit profile</button>

          </div>
          <div class="media-body mb-5 text-white">
            <h4 class="mt-0 mb-0">Mark Williams</h4>
            <p class="small mb-4">
              <i class="fas fa-map-marker-alt mr-2"></i>New York
            </p>
          </div>
        </div>
      </div>


      <div class="bg-light p-4 d-flex justify-content-end text-center">
        <ul class="list-inline mb-0">
          <li class="list-inline-item">
          
            </small>
          
        </ul>
      </div>
      <div class="px-4 py-3">
    <h5 class="mb-0">About 
        <button class="btn btn-link text-muted" onclick="editAbout()">Edit</button>
        <!-- Add an anchor tag with the href attribute pointing to changebio.php -->
        <a href="changebio.php" class="btn btn-link text-muted">Change Bio</a>
    </h5>
    <div class="p-4 rounded shadow-sm bg-light" id="about-section">
        <p class="font-italic mb-0" id="about-text">Web Developer</p>
        <p class="font-italic mb-0">Lives in New York</p>
        <p class="font-italic mb-0">Photographer</p>
    </div>
</div>


     <!-- New post form -->
     <div class="px-4 py-3">
        <h5 class="mb-0">Create a New Post</h5>
        <form action="../actions/create_post.php" method="POST" enctype="multipart/form-data">
          <div class="form-group">
            <label for="postImage">Upload Image</label>
            <input type="file" class="form-control-file" id="postImage" name="image" accept="image/*" required>
          </div>
          <div class="form-group">
            <label for="postCaption">Caption</label>
            <textarea class="form-control" id="postCaption" name="caption" rows="3" required></textarea>
          </div>
          <button type="submit" class="btn btn-primary">Post</button>
        </form>
      </div>
</div>
<h5 class="mb-0">Recent photos</h5>

        <!-- Post -->
        <?php

// Fetch all posts from the database
$sql = "SELECT * FROM post WHERE user_id = $user_id ORDER BY created_at DESC";
$result = $conn->query($sql);

// Check if there are any posts
if ($result->num_rows > 0) {
    // Output data of each row
    while($row = $result->fetch_assoc()) {
        // Display each post
		echo '<div class="card" style="width: 18rem;">
		<img src="' . $row['picture_path'] . '" class="card-img-top" alt="...">
		<div class="card-body">
			<h5 class="card-title">' . $row['content'] . '</h5>
			<p class="card-text">Created at ' . $row['created_at'] . '</p>
		</div>';
    }
} else {
    // Display a message if there are no posts
    echo "No posts found.";
}


// Close the database connection
$conn->close();
?>

<script>
    function editAbout() {
        // Get the existing about text
        const aboutText = document.getElementById('about-text').innerText.trim();

        // Create a textarea element
        const textarea = document.createElement('textarea');
        textarea.classList.add('form-control');
        textarea.value = aboutText;

        // Replace the existing about text with the textarea
        const aboutSection = document.getElementById('about-section');
        aboutSection.innerHTML = '';
        aboutSection.appendChild(textarea);

        // Focus on the textarea
        textarea.focus();

        // Add event listener to handle saving the edited about text
        textarea.addEventListener('blur', function () {
            saveAbout(textarea.value);
        });
    }

    function saveAbout(newAbout) {
        // Here you can send an AJAX request to save the new about text to the server
        // For demonstration purposes, let's just update the UI with the new text
        const aboutSection = document.getElementById('about-section');
        aboutSection.innerHTML = `<p class="font-italic mb-0">${newAbout}</p>`;
        // Add the "Edit" button again after saving
        aboutSection.innerHTML += '<button class="btn btn-link text-muted" onclick="editAbout()">Edit</button>';
    }
</script>

      </div>
      <div class="py-4 px-4">
        <div class="d-flex align-items-center justify-content-between mb-3">
          <a href="#" class="btn btn-link text-muted">Show all</a>

</div>

<!-- Bootstrap JS -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<!-- Font Awesome JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/js/all.min.js"></script>

<!-- Custom JS -->
<script src="./js/profile.js"></script>

<script>
    function openProfilePictureModal() {
      // Example: Open a modal with file input for uploading a new profile picture
      // You can replace this with your own modal implementation
      const fileInput = document.createElement('input');
      fileInput.type = 'file';
      fileInput.accept = 'image/*';
  
      fileInput.addEventListener('change', function () {
        const file = this.files[0];
        if (file) {
          const reader = new FileReader();
          reader.onload = function () {
            const profilePicture = document.getElementById('profile-picture');
            profilePicture.src = reader.result;
            // Here you can upload the file to the server using AJAX
          };
          reader.readAsDataURL(file);
        }
      });
  
      fileInput.click();
    }
    
  </script>
  <!-- Add this script to the end of your HTML body -->
<script>
    // Function to display modal with enlarged image
    function displayModal(imageSrc) {
        // Get the modal element
        var modal = document.getElementById('myModal');

        // Get the image element and set its source
        var modalImg = document.getElementById("img01");
        modalImg.src = imageSrc;

        // Display the modal
        modal.style.display = "block";
    }

    // Get all the images with class "img-fluid" (recent photos)
    var images = document.getElementsByClassName("img-fluid");

    // Loop through each image and add a click event listener
    for (var i = 0; i < images.length; i++) {
        images[i].addEventListener('click', function() {
            // When an image is clicked, display the modal with the enlarged image
            displayModal(this.src);
        });
    }

    // Function to close the modal
    function closeModal() {
        document.getElementById('myModal').style.display = "none";
    }
</script>

<!-- Add this modal at the end of your HTML body -->
<div id="myModal" class="modal">
    <span class="close" onclick="closeModal()">&times;</span>
    <img class="modal-content" id="img01">
</div>





<!-- Add this script to the end of your HTML body -->
<script>
  // Function to handle form submission for new post
  document.addEventListener('DOMContentLoaded', function () {
    const newPostForm = document.querySelector('#newPostForm');

    newPostForm.addEventListener('submit', function (event) {
      event.preventDefault(); // Prevent the default form submission

      // Get the form data
      const formData = new FormData(newPostForm);

      // Perform any client-side validation here if needed

      // Send the form data to the server using Fetch API
      fetch('../actions/create_post.php', {
        method: 'POST',
        body: formData,
      })
      .then(response => {
        if (response.ok) {
          // If the request is successful, reload the page to see the new post
          window.location.reload();
        } else {
          // Handle error if needed
          console.error('Error:', response.statusText);
        }
      })
      .catch(error => {
        console.error('Error:', error);
      });
    });
  });
</script>
</body>
</html>
