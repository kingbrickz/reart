<?php
// Include the connection settings file
session_start();
include("settings/connection.php");

 ?>
<!DOCTYPE html>


<html>
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>REART</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1,
      user-scalable=no">
    <link rel="stylesheet" href="assets/css/main.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  </head>
  <body class="is-preload">
    <!-- Wrapper -->
    <div id="wrapper">
      <!-- Header -->
      <header id="header">
        <h1><a href="index.html">REART<br>
          </a></h1>
        <nav class="links">
          <ul>
            <li> <a href="view/profile.php">PROFILE</a><br>
            </li>
            <li><a href="login/Signin.php" moz-do-not-send="true">LOGIN</a><br>
            </li>
          </ul>
        </nav>
    
		
		  
        </article>
        <!-- Post -->
		<?php

// Fetch all posts from the database
$sql = "SELECT * FROM post ORDER BY created_at DESC ";
$result = $conn->query($sql);

// Check if there are any posts
if ($result->num_rows > 0) {
    // Output data of each row
    while($row = $result->fetch_assoc()) {
        // Display each post
		echo '<div class="card" style="width: 18rem;">
		<img src="' . $row['picture_path'] . '" class="card-img-top" alt="...">
		<div class="card-body">
			<h5 class="card-title">' . $row['content'] . '</h5>
			<p class="card-text">Created at ' . $row['created_at'] . '</p>
		</div>';
    }
} else {
    // Display a message if there are no posts
    echo "No posts found.";
}


// Close the database connection
$conn->close();
?>
        <!-- Pagination -->

        <ul class="actions pagination">
          <li><a href="" class="disabled button large previous">Previous
              Page</a></li>
          <li><a href="#" class="button large next">Next Page</a></li>
        </ul>
      </div>
      <!-- Sidebar -->
      <section id="sidebar">
        <!-- Intro -->
        <section id="intro"> <a href="#" class="logo"><img
              src="images/logo.jpg" alt=""></a>
          <header>
            <h2>REART<br>
            </h2>
            <p>A WEBSITE THAT REDEFINES HOW ART IS CONSUMED <br>
            </p>
          </header>

        </section>
        <!-- Mini Posts -->
        <section>
          <div class="mini-posts">
            <!-- Mini Post -->
            <article class="mini-post">
              <header>
                <h3><a href="single.html">Vitae sed condimentum</a></h3>
                <time class="published" datetime="2015-10-20">October
                  20, 2015</time> <a href="#" class="author"><img
                    src="images/avatar.jpg" alt=""></a> </header>
              <a href="single.html" class="image"><img
                  src="images/pic04.jpg" alt=""></a> </article>
            <!-- Mini Post -->
            <article class="mini-post">
              <header>
                <h3><a href="single.html">Rutrum neque accumsan</a></h3>
                <time class="published" datetime="2015-10-19">October
                  19, 2015</time> <a href="#" class="author"><img
                    src="images/avatar.jpg" alt=""></a> </header>
              <a href="single.html" class="image"><img
                  src="images/pic05.jpg" alt=""></a> </article>
            <!-- Mini Post -->
            <article class="mini-post">
              <header>
                <h3><a href="single.html">Odio congue mattis</a></h3>
                <time class="published" datetime="2015-10-18">October
                  18, 2015</time> <a href="#" class="author"><img
                    src="images/avatar.jpg" alt=""></a> </header>
              <a href="single.html" class="image"><img
                  src="images/pic06.jpg" alt=""></a> </article>
            <!-- Mini Post -->
            <article class="mini-post">
              <header>
                <h3><a href="single.html">Enim nisl veroeros</a></h3>
                <time class="published" datetime="2015-10-17">October
                  17, 2015</time> <a href="#" class="author"><img
                    src="images/avatar.jpg" alt=""></a> </header>
              <a href="single.html" class="image"><img
                  src="images/pic07.jpg" alt=""></a> </article>
          </div>
        </section>
        <!-- Posts List -->
        <section>
          <ul class="posts">
            <li>
              <article>
                <header>
                  <h3><a href="single.html">Lorem ipsum fermentum ut
                      nisl vitae</a></h3>
                  <time class="published" datetime="2015-10-20">October
                    20, 2015</time> </header>
                <a href="single.html" class="image"><img
                    src="images/pic08.jpg" alt=""></a> </article>
            </li>
            <li>
              <article>
                <header>
                  <h3><a href="single.html">Convallis maximus nisl
                      mattis nunc id lorem</a></h3>
                  <time class="published" datetime="2015-10-15">October
                    15, 2015</time> </header>
                <a href="single.html" class="image"><img
                    src="images/pic09.jpg" alt=""></a> </article>
            </li>
            <li>
              <article>
                <header>
                  <h3><a href="single.html">Euismod amet placerat
                      vivamus porttitor</a></h3>
                  <time class="published" datetime="2015-10-10">October
                    10, 2015</time> </header>
                <a href="single.html" class="image"><img
                    src="images/pic10.jpg" alt=""></a> </article>
            </li>
            <li>
              <article>
                <header>
                  <h3><a href="single.html">Magna enim accumsan tortor
                      cursus ultricies</a></h3>
                  <time class="published" datetime="2015-10-08">October
                    8, 2015</time> </header>
                <a href="single.html" class="image"><img
                    src="images/pic11.jpg" alt=""></a> </article>
            </li>
            <li>
              <article>
                <header>
                  <h3><a href="single.html">Congue ullam corper lorem
                      ipsum dolor</a></h3>
                  <time class="published" datetime="2015-10-06">October
                    7, 2015</time> </header>
                <a href="single.html" class="image"><img
                    src="images/pic12.jpg" alt=""></a> </article>
            </li>
          </ul>
        </section>
        <!-- About -->
        <section class="blurb">
          <h2>About</h2>
          <p>Mauris neque quam, fermentum ut nisl vitae, convallis
            maximus nisl. Sed mattis nunc id lorem euismod amet
            placerat. Vivamus porttitor magna enim, ac accumsan tortor
            cursus at phasellus sed ultricies.</p>
       
        </section>
       
        </section>
      </section>
    </div>
    <!-- Scripts -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/browser.min.js"></script>
    <script src="assets/js/breakpoints.min.js"></script>
    <script src="assets/js/util.js"></script>
    <script src="assets/js/main.js"></script>
  </body>
</html>
