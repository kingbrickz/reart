<?php
    echo "<input " . "type='text' " . "placeholder='    Create a Post " . $_SESSION['username'] . " ?'" . "class='inputbar' onclick='openPostEditor()'>";